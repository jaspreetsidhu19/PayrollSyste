//
//  IPrintable.swift
//  Project
//
//  Created by MacStudent on 2018-07-26.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
protocol IPrintable
{
    func PrintMyData()
}
