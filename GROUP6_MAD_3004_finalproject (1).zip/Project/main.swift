//
//  main.swift
//  Project
//
//  Created by MacStudent on 2018-07-26.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

let fixed = FixedBasedPartTime(empName: "prdeep", age: 23, rate: 18, hoursWorked: 25, fixedAmount : 100)
let c1 = CommissionBasedPartTime(empname: "parm", age: 25, rate: 15, hoursWorked: 21, commissionPer: 40)
let i1 = intern(empname: "raman", age: 30, schoolName: "SBBS")
let f1 = FullTime(empname: "parm", age: 25, salary: 8000, bonus: 1000)
//var payroll = [1:f1 , 2:c1, 3:i1,4:fixed]

print("Press 1 for Fixed based part time employee")
print("Press 2 for commission based part time employee")
print("Press 3 for Intern")
print("Press 4 for Full time")
print("select which employee data you want to print")
var a = Int(readLine()!)
switch(a)
{
case 1:
    
    print("Employee is Fixed Based part time")
    //  print(payroll[1]?.empName ?? "" , payroll[1]?.age ?? "")
    fixed.PrintMyData()
    let car = Car(vehicleMake: "BMW", vehiclePlate: "19994", carBootspace: 100)
    car.PrintMyData()
    print(".................................\n")
case 2:
    
    print("Employee is commileton Based part time")
    
    c1.PrintMyData()
    let m2 = Motorcycle(vehicleMake: "Enfield", vehiclePlate: "19994", motorcycleColour: "black")
    m2.PrintMyData()
    print(".................................\n")
case 3:
    print("Employee is intern")
    
    i1.PrintMyData()
    let m2 = Motorcycle(vehicleMake: "Enfield", vehiclePlate: "19994", motorcycleColour: "black")
    m2.PrintMyData()
    print("................................\n")
case 4:
   print("Employee is FullTime")
   print(".....................\n")
   let car = Car(vehicleMake: "BMW", vehiclePlate: "19994", carBootspace: 100)
   f1.PrintMyData()
   car.PrintMyData()
   print(".................................\n")
default:
    print("No data")
}








