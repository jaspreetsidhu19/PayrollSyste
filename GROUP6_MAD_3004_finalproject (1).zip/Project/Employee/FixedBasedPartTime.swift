//
//  FixedBasedPartTime.swift
//  Project
//
//  Created by MacStudent on 2018-07-28.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class FixedBasedPartTime: PartTime
{
    var fixedAmount: Double!
    init(empName: String,age: Int,rate: Double, hoursWorked: Double, fixedAmount : Double)
    {
        self.fixedAmount = fixedAmount
        super.init(empname: empName, age: age, rate: rate, hoursWorked: hoursWorked)
    }
    func calEarnings1() -> Double
    {
        return (Double)(hoursWorked*rate) + fixedAmount
    }
    override func PrintMyData() {
        
        super.PrintMyData()
         print(" Earning : \(calEarnings1())")
        
    }
}
