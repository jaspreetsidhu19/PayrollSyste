//
//  PartTime.swift
//  Project
//
//  Created by MacStudent on 2018-07-26.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class PartTime: Employee
{
    var rate: Double
    var hoursWorked: Double
    //var vehicle : Vehicle
    init(empname: String ,age : Int, rate: Double, hoursWorked: Double) {
        
        self.rate = rate
        self.hoursWorked = hoursWorked
       // self.vehicle = vehicle
        super.init(empName: empname, age: age)
    }
    override func PrintMyData() {
       
        super.PrintMyData()
        
        print("Rate : \(rate) \n Hours Worked : \(hoursWorked)")
    }
}

