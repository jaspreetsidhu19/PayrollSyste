//
//  CommissionBasedPartTime.swift
//  Project
//
//  Created by MacStudent on 2018-07-28.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class CommissionBasedPartTime: PartTime
{
    var commissionPer : Double?
    init(empname: String ,age : Int,rate: Double, hoursWorked: Double,commissionPer : Double)
    {
        self.commissionPer = commissionPer
        super.init(empname: empname, age: age, rate: rate, hoursWorked: hoursWorked)
    }
     func calEarnings() -> Double
    {
        return (Double)(hoursWorked*rate) + (Double(hoursWorked*rate)*(commissionPer!/100))
    }
    override func PrintMyData() {
        
        super.PrintMyData()
        print(" Earning : \(calEarnings())")
    }
}
