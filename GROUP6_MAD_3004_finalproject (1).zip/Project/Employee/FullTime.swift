//
//  FullTime.swift
//  Project
//
//  Created by MacStudent on 2018-07-26.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class FullTime: Employee
{
    var salary : Double!
    var bonus  : Double!
    init(empname: String ,age : Int, salary:Double,bonus:Double)
    {
        
        self.salary=salary
        self.bonus=bonus
         super.init(empName: empname, age: age)
    }
    func calcEarnings() -> Double
    {
        return salary+bonus
    }
    
    override func PrintMyData() {
        
        super.PrintMyData()
        
        print("Total salary : \(calcEarnings())")
        print("Employee has a car")
    }
    
}
