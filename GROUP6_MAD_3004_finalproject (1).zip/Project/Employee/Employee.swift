//
//  Employee.swift
//  Project
//
//  Created by MacStudent on 2018-07-26.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
let date = Date()
let calender = Calendar.current
let year = calender.component(.year,from : date)
class Employee: IPrintable
{
    
    var empName : String!
    var age : Int!
  //  var vehicle : Vehicle
    init(empName: String,age: Int )
    {
        self.empName = empName
        self.age = age
       // self.vehicle = vehicle
    }
    func calcBirthYear() -> Int
    {
        return year-age
    }
    func PrintMyData() {
        print("Employee name : \(empName!) \n Year of birth : \(calcBirthYear()) \n Age : \(age!)")
    }
    
    
    
    
    
    
}
