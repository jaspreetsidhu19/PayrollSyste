//
//  Intern.swift
//  Project
//
//  Created by MacStudent on 2018-07-26.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class intern:Employee
{
    var schoolName: String?
   // var courseName: String?
    
    init(empname: String ,age : Int,schoolName: String)
    {
       
       self.schoolName = schoolName
       // self.courseName = courseName
          super.init(empName: empname, age: age)
        
    }
    override func PrintMyData() {
       
        super.PrintMyData()
        
        print("School name : \(schoolName!)" )
         print("Employee has a Motorcycle")
        
    }
}
