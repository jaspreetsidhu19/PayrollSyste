//
//  Motorcycle.swift
//  Project
//
//  Created by MacStudent on 2018-07-26.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Motorcycle: Vehicle
{
    var motorcycleColour: String!
    
    init( vehicleMake : String ,vehiclePlate : String ,motorcycleColour: String)
    {
        super.init(vehicleMake: vehicleMake, vehiclePlate: vehiclePlate)
        self.motorcycleColour = motorcycleColour
    }
    override func PrintMyData()
    {
        super.PrintMyData()
        print("vehicle color : \(motorcycleColour!)")
    }
   
}
    

