//
//  Car.swift
//  Project
//
//  Created by MacStudent on 2018-07-26.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Car: Vehicle
{
    var carBootspace: Int!

init(vehicleMake: String, vehiclePlate: String, carBootspace: Int)
{
    super.init(vehicleMake: vehicleMake, vehiclePlate: vehiclePlate)
    self.carBootspace = carBootspace
    
}
    override func PrintMyData()
    {
        super.PrintMyData()
        print(" car bootspace : \(carBootspace!)")
    }
    
}
