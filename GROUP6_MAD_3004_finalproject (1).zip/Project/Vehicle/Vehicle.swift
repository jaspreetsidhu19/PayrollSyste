//
//  Vehicle.swift
//  Project
//
//  Created by MacStudent on 2018-07-26.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Vehicle : IPrintable
{
    var vehicleMake: String!
    var vehiclePlate: String!
    

init (vehicleMake: String, vehiclePlate: String)
{
    self.vehicleMake = vehicleMake
    self.vehiclePlate = vehiclePlate
}
func PrintMyData()
{
    print("vehicle make : \(vehicleMake!) \n vehicle plate : \(vehiclePlate!)")
}
}





